from pyrogram import filters

class config:
    
    #Client
    API_ID = 20028561
    API_HASH = "0f3793daaf4d3905e55b0e44d8719cad"
    BOT_TOKEN = "7696106753:AAEXvSHg_0x79JYDcx8Mf08icGynkz3n7L8"
    BOT_NAME = "Itsuki"
    BOT_USERNAME = "ItsukiProbot"
    BOT_ID = 7696106753
    WORKERS = 20
    MAX_MESSAGE_CACHE_SIZE = 150
    MAX_CONCURRENT_TRANSMISSIONS = 10
    SESSION_STRING = "BQExnJEAMIi22ZrjCW30-BfuB-Xr7HsP0kzf70qbAU3h_NS9whGWJFyGlZcYp4lxlYTZ6Ey19oXt6nCFIZKaIWn3QAwjG8utCedDVuqvCeM_RVlzvr6ckxrYolEwOW3KcMy3S-HkrLA6-rlLRo1bZ06V77ropOpXlk7XtO19wQ9mWCV6nXbHSkkXKB6uVN4X74n7QJijBcvy8F-TF8uR19Z1LEmX4iVlLR6jP18L96ZO5zN_DXceiiqlfBm7WMOEZ1T0qgUD3L3nYgxrzeHxDJ3czJXmIsRdqkUzgXgAcvRmxyJ7tcCwxq3KNsHoWJ6JNCv5Ye-lZs51tJzRlp9BBL3MZeeS0AAAAAHFk6FnAA"
    START_STICKER_FILE_ID = [
        "CAACAgUAAxkBAAJF1WfXBAL0fHawQ7F3Lx7vWVxgKBrEAAIEEAACfuWIVI0tzGf2AAGXpx4E",
        "CAACAgUAAxkBAAIBamd-MjbOYhHAvF7Y-B0SXW7OpdFyAAJFEgAC0cHwVzMeKhyob9zqHgQ",
    ]
     
    #Git
    GIT_USERNAME = "Senpaiii10"
    GIT_URL_WITH_TOKEN = "https://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@github.com/john-wick00/Yumeko.git" 


    #Info
    BOT_VERSION = "5.0"
    OWNER_ID = 5630057244
    OWNER_USERNAME = "Senpaiii10"
    SUPPORT_CHAT = -1002611576730
    SUPPORT_CHAT_USERNAME = "Domihoes"
    SUPPORT_CHAT_LINK = "https://t.me/Domihoes"
    LOG_CHANNEL = -1002253145563
    ERROR_LOG_CHANNEL = -1002253145563
    DOWNLOAD_LOCATION = "./downloads"
    COMMAND_PREFIXES = ["/" , "!" , "." , "#" , "$" , "%" , "&" , "?"] 
    CMD_STARTERS = "/.!&#%$"
    STATS_IMG_URL = "https://files.catbox.moe/3vk7gw.jpg"
    START_IMG_URL = "https://files.catbox.moe/z9cvyy.jpg"
    HELP_IMG_URL = "https://files.catbox.moe/59mbah.jpg"
    ALIVE_IMG_URL = "https://files.catbox.moe/zn7kkc.jpg"
    
    #Database
    MONGODB_URI = "mongodb://localhost:27017"
    DATABASE_NAME = "Yumeko"

    #API
    ARQ_API_KEY = "RLWCED-WZASYO-AWOLTB-ITBWTP-ARQ"
    ARQ_API_URL = "arq.hamker.dev"
    CRICKET_API_URL = "https://sugoi-api.vercel.app/cricket"
    FOOTBALL_API_URL = "https://sugoi-api.vercel.app/football"
    BINGSEARCH_URL = "https://sugoi-api.vercel.app/search"
    NEWS_URL = "https://sugoi-api.vercel.app/news?keyword={}"
    shayri_api_url = "https://hindi-quotes.vercel.app/random"
    BASE_URL = "https://api.waifu.pics"
    OPENAI_KEY = "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"
    Movie_Api = "5d3274c3bb08b4276482436c8444abc0"
    Movie_RAC = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI1ZDMyNzRjM2JiMDhiNDI3NjQ4MjQzNmM4NDQ0YWJjMCIsIm5iZiI6MTczMzIyMjgxMy42OTQwMDAyLCJzdWIiOiI2NzRlZTE5ZDJjZTRjZTdkZDYwOTU2YjAiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.aXfQw0_CRrKl2iSJd9tFE1TVbWWVYNgysWkUVlwzyRg"
    Pokedex = "https://sugoi-api.vercel.app/pokemon?name={name_or_id}"
    LYRICS_GENIUS_TOKEN = "aUxVC27LbOxlX4e2tGU7K_dXcy895BvxaCZol4uBHS_Ul4g_W5ndQsr-4NFbMwg5"
    PASTEBIN_API = "Yt66ZvmHZoDIXsstRytMqzXNnMdKkf7m"



#============================================================  M  U  S  I  C  ============================================================#


API_ID = config.API_ID
API_HASH = config.API_HASH
BOT_TOKEN = config.BOT_TOKEN
MONGO_DB_URI = config.MONGODB_URI
DURATION_LIMIT_MIN = 60
LOG_GROUP_ID = config.LOG_CHANNEL
OWNER_ID = config.OWNER_ID
HEROKU_APP_NAME = "HEROKU_APP_NAME"
HEROKU_API_KEY = "HEROKU_API_KEY"
UPSTREAM_REPO = "https://github.com/AnonymousX1025/AnonXMusic"
UPSTREAM_BRANCH = "master"
GIT_TOKEN = None
SUPPORT_CHANNEL = config.SUPPORT_CHAT_LINK
SUPPORT_GROUP = config.SUPPORT_CHAT_LINK
AUTO_LEAVING_ASSISTANT = False
SPOTIFY_CLIENT_ID = "6bf7d415e88b4225902363f8ee48cbdd"
SPOTIFY_CLIENT_SECRET = "5dc9099056c14d63a9861803f4b2a4e0"
PLAYLIST_FETCH_LIMIT = 50
TG_AUDIO_FILESIZE_LIMIT =  50485760000
TG_VIDEO_FILESIZE_LIMIT = 507374182400
STRING1 = config.SESSION_STRING
STRING2 = None
STRING3 = None
STRING4 = None
STRING5 = None
BANNED_USERS = filters.user()
adminlist = {}
lyrical = {}
votemode = {}
autoclean = []
confirmer = {}
START_IMG_URL = config.START_IMG_URL
PING_IMG_URL = "https://i.ibb.co/FHYg1WC/5630057244-1727801848.jpg"
PLAYLIST_IMG_URL = "https://i.ibb.co/LzXQ0H5/5630057244-1727801842.jpg"
STATS_IMG_URL = config.STATS_IMG_URL
TELEGRAM_AUDIO_URL = "https://te.legra.ph/file/6298d377ad3eb46711644.jpg"
TELEGRAM_VIDEO_URL = "https://te.legra.ph/file/6298d377ad3eb46711644.jpg"
STREAM_IMG_URL = "https://te.legra.ph/file/bd995b032b6bd263e2cc9.jpg"
SOUNCLOUD_IMG_URL = "https://te.legra.ph/file/bb0ff85f2dd44070ea519.jpg"
YOUTUBE_IMG_URL = "https://te.legra.ph/file/6298d377ad3eb46711644.jpg"
SPOTIFY_ARTIST_IMG_URL = "https://te.legra.ph/file/37d163a2f75e0d3b403d6.jpg"
SPOTIFY_ALBUM_IMG_URL = "https://te.legra.ph/file/b35fd1dfca73b950b1b05.jpg"
SPOTIFY_PLAYLIST_IMG_URL = "https://te.legra.ph/file/95b3ca7993bbfaf993dcb.jpg"

def time_to_seconds(time):
    stringt = str(time)
    return sum(int(x) * 60**i for i, x in enumerate(reversed(stringt.split(":"))))

DURATION_LIMIT = int(time_to_seconds(f"{DURATION_LIMIT_MIN}:00"))
