import random
import requests
import urllib.parse
from bs4 import BeautifulSoup
from pyrogram import filters
from pyrogram.types import Message
from Yumeko import app as pgram
from config import config
from Yumeko.decorator.errors import error

async def fetch_wallpaper(query, limit=5):
    """Fetch wallpapers from wallhaven.cc based on the query"""
    base_url = "https://wallhaven.cc/search"
    query = urllib.parse.quote(query)
    wallpapers = []
    
    # Only fetch from the first page to keep response time reasonable
    url = f"{base_url}?q={query}&page=1"
    response = requests.get(url)
    
    if response.status_code != 200:
        return None
    
    # Parse HTML content
    soup = BeautifulSoup(response.content, "html.parser")
    
    # Find all thumbnail elements
    thumbnails = soup.find_all("a", class_="preview")
    if not thumbnails:
        return None
    
    # Limit the number of wallpapers to process
    thumbnails = thumbnails[:limit]
    
    for thumbnail in thumbnails:
        # Get the href which points to the image detail page
        detail_url = thumbnail["href"]
        
        # Fetch the detail page to get the original image link
        detail_response = requests.get(detail_url)
        if detail_response.status_code != 200:
            continue
        
        detail_soup = BeautifulSoup(detail_response.content, "html.parser")
        original_image = detail_soup.find("img", id="wallpaper")
        
        if original_image and "src" in original_image.attrs:
            image_url = original_image["src"]
            wallpapers.append(image_url)
    
    return wallpapers

@pgram.on_message(filters.command("wallpaper", config.COMMAND_PREFIXES))
@error
async def wallpaper_command(_, message: Message):
    """Handle the /wallpaper command"""
    # Check if query is provided
    if len(message.command) < 2:
        await message.reply_text("Please provide a search query. Example: /wallpaper nature")
        return
    
    # Get the search query
    query = " ".join(message.command[1:])
    
    # Send processing message
    processing_msg = await message.reply_text(f"Searching for wallpapers with query: '{query}'...")
    
    try:
        # Fetch wallpapers
        wallpapers = await fetch_wallpaper(query)
        
        if not wallpapers:
            await processing_msg.edit_text(f"No wallpapers found for query: '{query}'")
            return
        
        # Send a random wallpaper from the results
        wallpaper_url = random.choice(wallpapers)
        await message.reply_photo(
            wallpaper_url,
            caption=f"🖼 Wallpaper for: '{query}'\n🔗 Source: wallhaven.cc"
        )
        await processing_msg.delete()
        
    except Exception as e:
        await processing_msg.edit_text(f"Error fetching wallpaper: {str(e)}")

@pgram.on_message(filters.command("wallpapers", config.COMMAND_PREFIXES))
@error
async def multiple_wallpapers_command(_, message: Message):
    """Handle the /wallpapers command to get multiple wallpapers"""
    # Parse command arguments
    args = message.command[1:]
    
    if not args:
        await message.reply_text("Please provide a search query. Example: /wallpapers nature 3")
        return
    
    # Check if the last argument is a number (count)
    try:
        count = int(args[-1])
        query = " ".join(args[:-1])
    except ValueError:
        count = 3  # Default count
        query = " ".join(args)
    
    # Limit count to reasonable number
    count = min(count, 5)
    
    # Send processing message
    processing_msg = await message.reply_text(f"Searching for {count} wallpapers with query: '{query}'...")
    
    try:
        # Fetch wallpapers
        wallpapers = await fetch_wallpaper(query, limit=10)  # Fetch more to have options
        
        if not wallpapers:
            await processing_msg.edit_text(f"No wallpapers found for query: '{query}'")
            return
        
        # Send multiple wallpapers (up to count)
        sent_count = 0
        for wallpaper_url in wallpapers[:count]:
            await message.reply_photo(
                wallpaper_url,
                caption=f"🖼 Wallpaper {sent_count+1}/{count} for: '{query}'\n🔗 Source: wallhaven.cc"
            )
            sent_count += 1
            
        await processing_msg.delete()
        
    except Exception as e:
        await processing_msg.edit_text(f"Error fetching wallpapers: {str(e)}") 
        
__module__ = "𝖶𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋𝗌"

__help__ = """
𝖥𝖾𝗍𝖼𝗁 𝗁𝗂𝗀𝗁-𝗊𝗎𝖺𝗅𝗂𝗍𝗒 𝗐𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋𝗌 𝖿𝗋𝗈𝗆 𝖶𝖺𝗅𝗅𝗁𝖺𝗏𝖾𝗇.
 
**𝖢𝗈𝗆𝗆𝖺𝗇𝖽𝗌:**
- /𝗐𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋 [𝗊𝗎𝖾𝗋𝗒] - 𝖦𝖾𝗍 𝖺 𝗋𝖺𝗇𝖽𝗈𝗆 𝗐𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋 𝖻𝖺𝗌𝖾𝖽 𝗈𝗇 𝗍𝗁𝖾 𝗊𝗎𝖾𝗋𝗒.
 - /𝗐𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋𝗌 [𝗊𝗎𝖾𝗋𝗒] - 𝖦𝖾𝗍 𝗆𝗎𝗅𝗍𝗂𝗉𝗅𝖾 𝗐𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋𝗌 (𝗎𝗉 𝗍𝗈 𝟧) 𝖻𝖺𝗌𝖾𝖽 𝗈𝗇 𝗍𝗁𝖾 𝗊𝗎𝖾𝗋𝗒.
 
**𝖤𝗑𝖺𝗆𝗉𝗅𝖾𝗌:**
- `/𝗐𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋 𝗇𝖺𝗍𝗎𝗋𝖾` - 𝖥𝖾𝗍𝖼𝗁 𝖺 𝗋𝖺𝗇𝖽𝗈𝗆 𝗇𝖺𝗍𝗎𝗋𝖾 𝗐𝖺𝗅𝗅𝗉𝖺𝗉𝖾𝗋.
"""
