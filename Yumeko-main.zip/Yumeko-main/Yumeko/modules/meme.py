import aiohttp
from pyrogram import filters
from pyrogram.types import Message
from Yumeko import app as pgram
from config import config
from Yumeko.decorator.errors import error

async def fetch_meme(subreddit):
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://meme-api.com/gimme/{subreddit}") as response:
            data = await response.json()
            return data.get("url")

@pgram.on_message(filters.command("meme" , config.COMMAND_PREFIXES))
@error
async def wholesome_meme(_, message: Message):
    try:
        meme_url = await fetch_meme("wholesomememes")
        await message.reply_photo(meme_url)
    except Exception as e:
        await message.reply_text(f"Error fetching meme try again later !")

@pgram.on_message(filters.command("cursed" , config.COMMAND_PREFIXES))
@error
async def cursed_comments(_, message: Message):
    try:
        meme_url = await fetch_meme("cursedcomments")
        await message.reply_photo(meme_url)
    except Exception as e:
        await message.reply_text(f"Error fetching cursed comment try again later !")

@pgram.on_message(filters.command("shitpost" , config.COMMAND_PREFIXES))
@error
async def shitpost(_, message: Message):
    try:
        meme_url = await fetch_meme("shitposting")
        await message.reply_photo(meme_url)
    except Exception as e:
        await message.reply_text(f"Error fetching shitpost try again later !")


@pgram.on_message(filters.command(["teenmemes", "teenagers"] , config.COMMAND_PREFIXES))
@error
async def teen_meme(_, message: Message):
    try:
        meme_url = await fetch_meme("teenagers")
        await message.reply_photo(meme_url)
    except Exception as e:
        await message.reply_text(f"Error fetching teen meme try again later !") 
        
__module__ = "𝖬𝖾𝗆𝖾𝗌"

__help__ = """
𝖥𝖾𝗍𝖼𝗁 𝗋𝖺𝗇𝖽𝗈𝗆 𝗆𝖾𝗆𝖾𝗌 𝖿𝗋𝗈𝗆 𝗏𝖺𝗋𝗂𝗈𝗎𝗌 𝗌𝗎𝖻𝗋𝖾𝖽𝖽𝗂𝗍𝗌.
 
**𝖢𝗈𝗆𝗆𝖺𝗇𝖽𝗌:**
- /𝗆𝖾𝗆𝖾 - 𝖦𝖾𝗍 𝖺 𝗋𝖺𝗇𝖽𝗈𝗆 𝗐𝗁𝗈𝗅𝖾𝗌𝗈𝗆𝖾 𝗆𝖾𝗆𝖾
- /𝖼𝗎𝗋𝗌𝖾𝖽 - 𝖦𝖾𝗍 𝖺 𝖼𝗎𝗋𝗌𝖾𝖽 𝖼𝗈𝗆𝗆𝖾𝗇𝗍 𝗆𝖾𝗆𝖾
- /𝗌𝗁𝗂𝗍𝗉𝗈𝗌𝗍 - 𝖦𝖾𝗍 𝖺 𝗌𝗁𝗂𝗍𝗉𝗈𝗌𝗍 𝗆𝖾𝗆𝖾
- /𝗍𝖾𝖾𝗇𝗆𝖾𝗆𝖾𝗌 𝗈𝗋 /𝗍𝖾𝖾𝗇𝖺𝗀𝖾𝗋𝗌 - 𝖦𝖾𝗍 𝖺 𝗆𝖾𝗆𝖾 𝖿𝗋𝗈𝗆 𝗍𝗁𝖾 𝖳𝖾𝖾𝗇𝖺𝗀𝖾𝗋𝗌 𝗌𝗎𝖻𝗋𝖾𝖽𝖽𝗂𝗍
"""
